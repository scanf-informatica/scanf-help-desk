# Entregas

## Dashboard operacional
- [x] Exibir total de chamados, abertos, em andamento, resolvidos e atrasados.
- [x] Exibir distribuição por prioridade/categoria e desempenho dos técnicos com dados do estado atual.
- [x] Exibir tempo médio e alertas de SLA.

## Chamados
- [x] Permitir abrir chamado com protocolo automático, solicitante, setor, e-mail, título, descrição, categoria e prioridade.
- [x] Permitir visualizar, pesquisar e filtrar por protocolo, solicitante, categoria, prioridade, status e responsável.
- [x] Permitir alterar status, prioridade e técnico e registrar resposta/nota no histórico.
- [x] Exibir detalhe, timeline, SLA, anexos demonstráveis e diferenciação entre notas internas e resposta pública.

## SLA e dados de demonstração
- [x] Calcular vencimento por prioridade: Baixa 48h, Média 24h, Alta 8h e Crítica 2h.
- [x] Identificar chamados próximos do vencimento e vencidos.
- [ ] Incluir seed opcional de demonstração separado da base operacional.

## Relatórios e configurações
- [x] Exibir relatórios resumidos por período, categoria, prioridade e técnico.
- [x] Exportar relatório em CSV compatível com Excel.
- [x] Exibir configurações de categorias, prioridades, SLA, horário e dados institucionais.

## Full Stack — segunda etapa
- [x] Criar schema Drizzle/MySQL para usuários, sessões, chamados, categorias, departamentos, comentários, histórico, anexos e SLA.
- [x] Implementar migrações relacionais para tabelas e índices em banco MySQL vazio.
- [x] Implementar login/cadastro por e-mail e senha com hash scrypt, sessão persistida, recuperação de senha e rate limit.
- [x] Implementar autorização server-side para administrador, técnico e solicitante.
- [x] Implementar API para criar, listar, editar, atribuir e comentar chamados com histórico.
- [x] Implementar validação, upload e download de anexos em storage S3-compatible independente.
- [x] Conectar o carregamento e a criação de chamados da interface ao banco autenticado.
- [x] Validar typecheck, testes de segurança, build e endpoints protegidos.

## Qualidade
- [x] Interface responsiva com login próprio.
- [x] Integrar persistência server-side via API Express/Drizzle, sem localStorage como fonte operacional.
- [x] Incluir README e `.env.example`.
- [ ] Validar build e corrigir diagnósticos antes do checkpoint.
