# Relatório de revisão técnica — SCANF Help Desk

Data da revisão: 2026-11-03

## Validações executadas

- `pnpm check`: PASSOU — TypeScript sem erros.
- `pnpm test`: PASSOU — 2 arquivos, 6 testes.
- `pnpm build`: PASSOU — Vite e bundle do servidor gerados. Há somente um aviso não bloqueante do Vite sobre chunk frontend acima de 500 kB.
- `pnpm db:migrate`: não executado neste ambiente, pois não há `DATABASE_URL` de um MySQL disponível. Deve ser executado no deploy Railway, antes do processo do servidor.

## Correções realizadas

- Primeiro administrador protegido por `GET_LOCK` dentro de transação Drizzle; lock adquirido e liberado na mesma conexão física.
- Cookie de sessão `HttpOnly`, `SameSite=Lax`, `Secure` condicionado a HTTPS/produção e proteção de mutações por `Origin`/`Referer` same-origin.
- Rate limit de login compartilhado via Redis quando `REDIS_URL` está configurado, com fallback local explícito para desenvolvimento.
- Recuperação de senha com token armazenado somente como hash, expiração, uso único, revogação de sessões, endpoint de redefinição e integração SMTP configurável. Nenhuma resposta pública contém token.
- Upload direto presignado desativado por não permitir inspeção real antes da gravação. Upload validado limita 10 MiB, valida Base64, inspeciona assinatura binária e compara tipo declarado/detectado antes do S3.
- Dockerfile não fixa mais `PORT`; Railway injeta a porta e o processo escuta `0.0.0.0`. O start executa migrações antes do servidor.
- README reescrito sem alegações antigas de ausência de autenticação ou uso de localStorage como armazenamento operacional.
- CSV agora é baixado do endpoint protegido real; configurações carregam `/api/config`; dashboard, chamados, comentários, histórico, relatórios, técnicos e operações administrativas usam o backend.

## Dependências externas ainda necessárias

- MySQL: obrigatório para iniciar a operação e aplicar migrações.
- Redis: recomendado/necessário para rate limit compartilhado entre réplicas e reinícios; sem ele há fallback em memória.
- SMTP: necessário para efetivamente enviar e-mails de recuperação; sem ele o endpoint permanece genérico, mas não envia mensagens.
- S3-compatible storage: necessário para uploads/downloads de anexos.

## Observações

A identidade visual não foi refeita. O aviso de chunk grande pode ser tratado futuramente com code splitting, mas não impede publicação nem altera a correção funcional desta revisão.
