import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { toast } from "sonner";
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Bell,
  CalendarDays,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Filter,
  Headphones,
  LayoutDashboard,
  LifeBuoy,
  Menu,
  MessageSquare,
  MoreHorizontal,
  Paperclip,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Ticket,
  TrendingUp,
  UserRound,
  Users,
  X,
  Zap,
} from "lucide-react";

type Status =
  | "Aberto"
  | "Em análise"
  | "Em atendimento"
  | "Aguardando usuário"
  | "Aguardando terceiros"
  | "Resolvido"
  | "Fechado";
type Priority = "Baixa" | "Média" | "Alta" | "Crítica";
type Category = "Hardware" | "Software" | "Rede" | "Acesso" | "Outros";
type TicketItem = {
  id: string;
  protocol: string;
  requester: string;
  initials: string;
  department: string;
  email: string;
  title: string;
  description: string;
  category: Category;
  priority: Priority;
  status: Status;
  assignee: string;
  openedAt: string;
  resolvedAt?: string;
  dueAt: string;
  messages: {
    text: string;
    author: string;
    date: string;
    internal?: boolean;
  }[];
};

const priorities: Priority[] = ["Baixa", "Média", "Alta", "Crítica"];
const statuses: Status[] = [
  "Aberto",
  "Em análise",
  "Em atendimento",
  "Aguardando usuário",
  "Aguardando terceiros",
  "Resolvido",
  "Fechado",
];
const categories: Category[] = [
  "Hardware",
  "Software",
  "Rede",
  "Acesso",
  "Outros",
];
const slaHours: Record<Priority, number> = {
  Baixa: 48,
  Média: 24,
  Alta: 8,
  Crítica: 2,
};

function addHours(date: Date, hours: number) {
  return new Date(date.getTime() + hours * 3600000).toISOString();
}
function formatDate(value: string) {
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  })
    .format(new Date(value))
    .replace(" de ", " ");
}
function isOverdue(ticket: TicketItem) {
  return (
    ticket.status !== "Resolvido" &&
    ticket.status !== "Fechado" &&
    new Date(ticket.dueAt) < new Date()
  );
}
function getSlaState(ticket: TicketItem) {
  if (isOverdue(ticket)) return "Vencido";
  const hours = (new Date(ticket.dueAt).getTime() - Date.now()) / 3600000;
  return hours < 6 ? "Atenção" : "No prazo";
}
function initials(name: string) {
  return name
    .split(" ")
    .map(p => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}
const apiPriority: Record<Priority, string> = { Baixa: "low", Média: "medium", Alta: "high", Crítica: "critical" };
const apiStatus: Record<Status, string> = { Aberto: "open", "Em análise": "analyzing", "Em atendimento": "in_progress", "Aguardando usuário": "waiting_requester", "Aguardando terceiros": "waiting_third_party", Resolvido: "resolved", Fechado: "closed" };
const uiPriority: Record<string, Priority> = { low: "Baixa", medium: "Média", high: "Alta", critical: "Crítica" };
const uiStatus: Record<string, Status> = { open: "Aberto", analyzing: "Em análise", in_progress: "Em atendimento", waiting_requester: "Aguardando usuário", waiting_third_party: "Aguardando terceiros", resolved: "Resolvido", closed: "Fechado" };
function fromApiTicket(raw: any): TicketItem {
  const requester = raw.requester?.name ?? raw.requesterName ?? "Solicitante";
  return { id: String(raw.id), protocol: raw.protocol, requester, initials: initials(requester), department: raw.department?.name ?? "Sem departamento", email: raw.requester?.email ?? "", title: raw.title, description: raw.description, category: raw.category?.name ?? "Outros", priority: uiPriority[raw.priority] ?? "Média", status: uiStatus[raw.status] ?? "Aberto", assignee: raw.assignee?.name ?? "Sem atribuição", openedAt: raw.createdAt, resolvedAt: raw.resolvedAt ?? undefined, dueAt: raw.slaDueAt ?? new Date().toISOString(), messages: [] };
}
function StatusBadge({ value }: { value: Status }) {
  return (
    <span
      className={`status-badge status-${value.toLowerCase().replaceAll(" ", "-")}`}
    >
      <i />
      {value}
    </span>
  );
}
function PriorityBadge({ value }: { value: Priority }) {
  return (
    <span className={`priority-badge priority-${value.toLowerCase()}`}>
      {value}
    </span>
  );
}

export default function Home({ user, onLogout }: { user?: { name?: string; role?: string }; onLogout?: () => void } = {}) {
  const [tickets, setTickets] = useState<TicketItem[]>([]);
  const [technicians, setTechnicians] = useState<string[]>(["Sem atribuição"]);
  const [section, setSection] = useState("Visão geral");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("Todos os status");
  const [priorityFilter, setPriorityFilter] = useState("Todas as prioridades");
  const [categoryFilter, setCategoryFilter] = useState("Todas as categorias");
  const [assigneeFilter, setAssigneeFilter] = useState("Todos os responsáveis");
  const [selected, setSelected] = useState<TicketItem | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);

  useEffect(() => {
    fetch("/api/tickets", { credentials: "include" })
      .then(response => response.ok ? response.json() : null)
      .then(data => { if (data?.tickets) setTickets(data.tickets.map(fromApiTicket)); })
      .catch(() => toast.error("Não foi possível carregar os chamados do banco"));
  }, []);
  useEffect(() => {
    fetch("/api/technicians", { credentials: "include" }).then(response => response.ok ? response.json() : null).then(data => { if (data?.technicians) setTechnicians(["Sem atribuição", ...data.technicians.map((tech: { name: string }) => tech.name)]); });
  }, []);
  const metrics = useMemo(
    () => ({
      total: tickets.length,
      open: tickets.filter(t => t.status === "Aberto").length,
      progress: tickets.filter(t =>
        [
          "Em análise",
          "Em atendimento",
          "Aguardando usuário",
          "Aguardando terceiros",
        ].includes(t.status)
      ).length,
      solved: tickets.filter(t => ["Resolvido", "Fechado"].includes(t.status))
        .length,
      overdue: tickets.filter(isOverdue).length,
    }),
    [tickets]
  );
  const filtered = useMemo(
    () =>
      tickets.filter(
        t =>
          `${t.protocol} ${t.requester} ${t.title}`
            .toLowerCase()
            .includes(query.toLowerCase()) &&
          (statusFilter === "Todos os status" || t.status === statusFilter) &&
          (priorityFilter === "Todas as prioridades" ||
            t.priority === priorityFilter) &&
          (categoryFilter === "Todas as categorias" ||
            t.category === categoryFilter) &&
          (assigneeFilter === "Todos os responsáveis" ||
            t.assignee === assigneeFilter)
      ),
    [tickets, query, statusFilter, priorityFilter, categoryFilter, assigneeFilter]
  );
  const categoryData = categories
    .map(name => ({
      name,
      value: tickets.filter(t => t.category === name).length,
    }))
    .filter(x => x.value);
  const priorityData = priorities.map(name => ({
    name,
    value: tickets.filter(t => t.priority === name).length,
  }));
  const trendData = [
    { day: "Atual", abertos: metrics.open + metrics.progress, resolvidos: metrics.solved },
  ];

  function updateTicket(id: string, patch: Partial<TicketItem>) {
    setTickets(current =>
      current.map(t => (t.id === id ? { ...t, ...patch } : t))
    );
    setSelected(current =>
      current && current.id === id ? { ...current, ...patch } : current
    );
    const apiPatch: Record<string, unknown> = {};
    if (patch.status) apiPatch.status = apiStatus[patch.status];
    if (patch.priority) apiPatch.priority = apiPriority[patch.priority];
    if (patch.assignee) apiPatch.assigneeName = patch.assignee;
    if (Object.keys(apiPatch).length) fetch(`/api/tickets/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify(apiPatch) }).then(response => { if (!response.ok) toast.error("Alteração não autorizada pelo servidor"); });
  }
  async function openTicket(ticket: TicketItem) {
    const response = await fetch(`/api/tickets/${ticket.id}`, { credentials: "include" });
    if (!response.ok) { toast.error("Não foi possível carregar o chamado"); return; }
    const data = await response.json();
    setSelected({ ...ticket, messages: (data.comments ?? []).map((comment: any) => ({ text: comment.body, author: "Usuário do atendimento", date: comment.createdAt, internal: comment.internal })) });
  }
  async function addComment(id: string, body: string) {
    const response = await fetch(`/api/tickets/${id}/comments`, { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify({ body, internal: false }) });
    if (!response.ok) { toast.error("Não foi possível salvar o comentário"); return false; }
    const current = tickets.find(ticket => ticket.id === id); if (current) await openTicket(current); return true;
  }
  async function createTicket(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const priority = form.get("priority") as Priority;
    const now = new Date();
    const requester = String(form.get("requester"));
    const item: TicketItem = {
      id: crypto.randomUUID(),
      protocol: `#SCF-${1050 + tickets.length}`,
      requester,
      initials: initials(requester),
      department: String(form.get("department")),
      email: String(form.get("email")),
      title: String(form.get("title")),
      description: String(form.get("description")),
      category: form.get("category") as Category,
      priority,
      status: "Aberto",
      assignee: "Sem atribuição",
      openedAt: now.toISOString(),
      dueAt: addHours(now, slaHours[priority]),
      messages: [],
    };
    const apiResponse = await fetch("/api/tickets", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify({ title: item.title, description: item.description, category: item.category, priority: apiPriority[item.priority] }) });
    if (!apiResponse.ok) { toast.error("Não foi possível persistir o chamado no banco"); return; }
    const refreshed = await fetch("/api/tickets", { credentials: "include" });
    const refreshedData = refreshed.ok ? await refreshed.json() : null;
    if (!refreshedData?.tickets) { toast.error("Chamado criado, mas não foi possível recarregar a fila do banco"); return; }
    setTickets(refreshedData.tickets.map(fromApiTicket));
    setShowCreate(false);
    toast.success(`Chamado ${item.protocol} criado com sucesso`);
  }
  async function exportCsv() {
    const response = await fetch("/api/reports.csv", { credentials: "include" });
    if (!response.ok) { toast.error("Não foi possível gerar o relatório no servidor"); return; }
    const blob = await response.blob(); const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "relatorio-scanf-help-desk.csv"; a.click(); URL.revokeObjectURL(a.href);
    toast.success("Relatório exportado para Excel/CSV");
  }
  function exportPdf() { window.open("/api/reports.pdf", "_blank", "noopener,noreferrer"); }

  const nav = [
    { label: "Visão geral", icon: LayoutDashboard },
    { label: "Chamados", icon: Ticket, count: metrics.total },
    { label: "Relatórios", icon: BarChart3 },
    { label: "Configurações", icon: Settings2 },
  ];
  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? "mobile-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark">S</div>
          <div>
            <strong>SCANF</strong>
            <small>INFORMÁTICA</small>
          </div>
          <button aria-label="Fechar navegação" className="mobile-close" onClick={() => setMobileNav(false)}>
            <X size={18} />
          </button>
        </div>
        <div className="workspace">
          <span className="online-dot" /> Central de Operações{" "}
          <ChevronRight size={14} />
        </div>
        <nav>
          {nav.map(item => (
            <button
              key={item.label}
              className={section === item.label ? "active" : ""}
              onClick={() => {
                setSection(item.label);
                setMobileNav(false);
              }}
            >
              <item.icon size={18} />
              <span>{item.label}</span>
              {item.count && <b>{item.count}</b>}
            </button>
          ))}
        </nav>
        <div className="nav-label">ATENDIMENTO</div>
        <nav>
          <button
            onClick={() => {
              setSection("Chamados");
              setMobileNav(false);
            }}
          >
            <LifeBuoy size={18} />
            <span>Fila de atendimento</span>
            <b className="nav-alert">{metrics.overdue}</b>
          </button>
          <button onClick={() => toast.info("Nenhuma notificação nova")}>
            <Bell size={18} />
            <span>Notificações</span>
          </button>
        </nav>
        <div className="sidebar-footer">
          <div className="mini-profile">
            <div className="avatar avatar-cyan">SC</div>
            <div>
              <strong>{user?.name ?? "Usuário SCANF"}</strong>
              <small>{user?.role === "admin" ? "Administrador" : user?.role === "technician" ? "Técnico" : "Solicitante"}</small>
            </div>
            <MoreHorizontal size={17} />
          </div>
          <div className="system-status">
            <span />
            <div>
              <strong>Todos os serviços operacionais</strong>
              <small>Última sincronização agora</small>
            </div>
          </div>
        </div>
      </aside>
      <main className="main-content">
        <header className="topbar">
          <button aria-label="Abrir navegação" className="mobile-menu" onClick={() => setMobileNav(true)}>
            <Menu size={22} />
          </button>
          <div className="breadcrumb">
            <span>SCANF Help Desk</span>
            <ChevronRight size={14} />
            <strong>{section}</strong>
          </div>
          <div className="top-actions">
            <div className="top-search">
              <Search size={17} />
              <input
                placeholder="Buscar chamado..."
                value={query}
                onChange={e => setQuery(e.target.value)}
              />
            </div>
            <button
              aria-label="Ver notificações"
              className="icon-button"
              onClick={() => toast.info("Tudo em dia por aqui")}
            >
              <Bell size={18} />
              <i />
            </button>
            <button className="user-chip" onClick={onLogout} title="Sair">
              <span>AS</span>
              <strong>{user?.name ?? "Usuário SCANF"}</strong>
            </button>
          </div>
        </header>
        {section === "Visão geral" && (
          <Dashboard
            metrics={metrics}
            tickets={tickets}
            trendData={trendData}
            priorityData={priorityData}
            categoryData={categoryData}
            onOpen={openTicket}
            onCreate={() => setShowCreate(true)}
          />
        )}
        {section === "Chamados" && (
          <TicketsView
            tickets={filtered}
            query={query}
            setQuery={setQuery}
            statusFilter={statusFilter}
            setStatusFilter={setStatusFilter}
            priorityFilter={priorityFilter}
            setPriorityFilter={setPriorityFilter}
            categoryFilter={categoryFilter}
            setCategoryFilter={setCategoryFilter}
            assigneeFilter={assigneeFilter}
            setAssigneeFilter={setAssigneeFilter}
            technicians={technicians}
            onOpen={openTicket}
            onCreate={() => setShowCreate(true)}
          />
        )}
        {section === "Relatórios" && (
          <Reports tickets={tickets} technicians={technicians} onExport={exportCsv} onExportPdf={exportPdf} />
        )}
        {section === "Configurações" && <Settings technicians={technicians} />}
      </main>
      {selected && (
        <TicketDrawer
          ticket={selected}
          onClose={() => setSelected(null)}
          onUpdate={updateTicket}
          onComment={addComment}
          technicians={technicians}
        />
      )}
      {showCreate && (
        <CreateModal
          onClose={() => setShowCreate(false)}
          onSubmit={createTicket}
        />
      )}
    </div>
  );
}

function Dashboard({
  metrics,
  tickets,
  trendData,
  priorityData,
  categoryData,
  onOpen,
  onCreate,
}: {
  metrics: any;
  tickets: TicketItem[];
  trendData: any[];
  priorityData: any[];
  categoryData: any[];
  onOpen: (t: TicketItem) => void;
  onCreate: () => void;
}) {
  return (
    <div className="page">
      <div className="page-heading">
        <div>
          <div className="eyebrow">
            <Activity size={14} /> OPERAÇÃO EM TEMPO REAL
          </div>
          <h1>Visão geral da operação</h1>
          <p>Priorize o que precisa de atenção agora.</p>
        </div>
        <button className="primary-button" onClick={onCreate}>
          <Plus size={17} /> Novo chamado
        </button>
      </div>
      <div className="metric-grid">
        {[
          ["Total de chamados", metrics.total, Ticket, "blue"],
          ["Em aberto", metrics.open, Zap, "amber"],
          ["Em andamento", metrics.progress, Clock3, "purple"],
          ["Resolvidos", metrics.solved, CheckCircle2, "green"],
        ].map(([label, value, Icon, color]) => (
          <div className="metric-card" key={label as string}>
            <div className={`metric-icon ${color}`}>
              <Icon size={19} />
            </div>
            <div>
              <span>{label as string}</span>
              <strong>{value as number}</strong>
              <small>
                <TrendingUp size={12} /> 12,5% <em>vs. semana anterior</em>
              </small>
            </div>
          </div>
        ))}
      </div>
      <div className="alert-strip">
        <div className="alert-icon">
          <AlertTriangle size={17} />
        </div>
        <div>
          <strong>{metrics.overdue} chamados com SLA vencido</strong>
          <span>
            {" "}
            precisam de atenção imediata para evitar impacto na operação.
          </span>
        </div>
        <button
          onClick={() =>
            document
              .getElementById("latest-tickets")
              ?.scrollIntoView({ behavior: "smooth" })
          }
        >
          Ver chamados <ChevronRight size={15} />
        </button>
      </div>
      <div className="charts-grid">
        <div className="panel chart-panel">
          <div className="panel-heading">
            <div>
              <h3>Volume de atendimentos</h3>
              <span>Chamados abertos e resolvidos nos últimos 5 dias</span>
            </div>
            <button className="select-compact">
              Esta semana <ChevronRight size={14} />
            </button>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={trendData}>
              <defs>
                <linearGradient id="open" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2dd4ff" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#2dd4ff" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="done" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#7c8cff" stopOpacity={0.2} />
                  <stop offset="100%" stopColor="#7c8cff" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="4 4"
                stroke="#e9edf2"
                vertical={false}
              />
              <XAxis
                dataKey="day"
                axisLine={false}
                tickLine={false}
                tick={{ fill: "#8793a5", fontSize: 12 }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fill: "#8793a5", fontSize: 12 }}
              />
              <Tooltip />
              <Area
                type="monotone"
                dataKey="abertos"
                stroke="#2dd4ff"
                fill="url(#open)"
                strokeWidth={2.5}
              />
              <Area
                type="monotone"
                dataKey="resolvidos"
                stroke="#7c8cff"
                fill="url(#done)"
                strokeWidth={2.5}
              />
            </AreaChart>
          </ResponsiveContainer>
          <div className="legend">
            <span>
              <i className="cyan-dot" /> Abertos
            </span>
            <span>
              <i className="purple-dot" /> Resolvidos
            </span>
          </div>
        </div>
        <div className="panel donut-panel">
          <div className="panel-heading">
            <div>
              <h3>Por categoria</h3>
              <span>Distribuição atual</span>
            </div>
            <MoreHorizontal size={18} />
          </div>
          <div className="donut-wrap">
            <ResponsiveContainer width="48%" height={170}>
              <PieChart>
                <Pie
                  data={categoryData}
                  dataKey="value"
                  innerRadius={48}
                  outerRadius={68}
                  paddingAngle={4}
                >
                  {categoryData.map((_, i) => (
                    <Cell
                      key={i}
                      fill={
                        ["#2dd4ff", "#7c8cff", "#f6b94b", "#34d399", "#aab4c5"][
                          i % 5
                        ]
                      }
                    />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="category-legend">
              {categoryData.map((c, i) => (
                <div key={c.name}>
                  <span>
                    <i
                      style={{
                        background: [
                          "#2dd4ff",
                          "#7c8cff",
                          "#f6b94b",
                          "#34d399",
                          "#aab4c5",
                        ][i % 5],
                      }}
                    />
                    {c.name}
                  </span>
                  <strong>{c.value}</strong>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="lower-grid">
        <div className="panel" id="latest-tickets">
          <div className="panel-heading">
            <div>
              <h3>Chamados recentes</h3>
              <span>Atualizados nos últimos atendimentos</span>
            </div>
            <button className="text-button" onClick={() => onOpen(tickets[0])}>
              Ver todos <ChevronRight size={15} />
            </button>
          </div>
          <TicketTable tickets={tickets.slice(0, 5)} onOpen={onOpen} />
        </div>
        <div className="panel priority-panel">
          <div className="panel-heading">
            <div>
              <h3>Prioridade</h3>
              <span>Chamados por urgência</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart
              data={priorityData}
              layout="vertical"
              margin={{ left: 4, right: 12 }}
            >
              <CartesianGrid
                strokeDasharray="4 4"
                horizontal={false}
                stroke="#edf0f4"
              />
              <XAxis type="number" hide />
              <YAxis
                dataKey="name"
                type="category"
                axisLine={false}
                tickLine={false}
                tick={{ fill: "#66758a", fontSize: 12 }}
                width={52}
              />
              <Tooltip cursor={{ fill: "#f6f8fb" }} />
              <Bar dataKey="value" radius={[0, 5, 5, 0]}>
                {priorityData.map((_, i) => (
                  <Cell
                    key={i}
                    fill={["#aab4c5", "#2dd4ff", "#f6b94b", "#ff6b7d"][i]}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

function TicketsView({
  tickets,
  query,
  setQuery,
  statusFilter,
  setStatusFilter,
  priorityFilter,
  setPriorityFilter,
  categoryFilter,
  setCategoryFilter,
  assigneeFilter,
  setAssigneeFilter,
  technicians,
  onOpen,
  onCreate,
}: any) {
  return (
    <div className="page">
      <div className="page-heading">
        <div>
          <div className="eyebrow">
            <Ticket size={14} /> CENTRAL DE ATENDIMENTO
          </div>
          <h1>Todos os chamados</h1>
          <p>Gerencie, atribua e acompanhe cada solicitação.</p>
        </div>
        <button className="primary-button" onClick={onCreate}>
          <Plus size={17} /> Novo chamado
        </button>
      </div>
      <div className="toolbar">
        <div className="filter-search">
          <Search size={17} />
          <input
            placeholder="Buscar por protocolo, título ou solicitante"
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
        </div>
        <div className="filter-select">
          <Filter size={15} />
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
          >
            <option>Todos os status</option>
            {statuses.map(s => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </div>
        <div className="filter-select">
          <SlidersHorizontal size={15} />
          <select
            value={priorityFilter}
            onChange={e => setPriorityFilter(e.target.value)}
          >
            <option>Todas as prioridades</option>
            {priorities.map(p => (
              <option key={p}>{p}</option>
            ))}
          </select>
        </div>
        <div className="filter-select">
          <Filter size={15} />
          <select value={categoryFilter} onChange={e => setCategoryFilter(e.target.value)}>
            <option>Todas as categorias</option>
            {categories.map(c => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="filter-select">
          <UserRound size={15} />
          <select value={assigneeFilter} onChange={e => setAssigneeFilter(e.target.value)}>
            <option>Todos os responsáveis</option>
            {technicians.map((t: string) => <option key={t}>{t}</option>)}
          </select>
        </div>
      </div>
      <div className="panel table-panel">
        <div className="table-meta">
          <span>
            <strong>{tickets.length}</strong> chamados encontrados
          </span>
          <span>
            Ordenado por atualização <ChevronRight size={14} />
          </span>
        </div>
        <TicketTable tickets={tickets} onOpen={onOpen} />
      </div>
    </div>
  );
}
function TicketTable({
  tickets,
  onOpen,
}: {
  tickets: TicketItem[];
  onOpen: (t: TicketItem) => void;
}) {
  return (
    <div className="ticket-table-wrap">
      <table className="ticket-table">
        <thead>
          <tr>
            <th>Chamado</th>
            <th>Solicitante</th>
            <th>Categoria</th>
            <th>Prioridade</th>
            <th>Status</th>
            <th>SLA</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {tickets.map(t => (
            <tr key={t.id} onClick={() => onOpen(t)}>
              <td>
                <strong className="protocol">{t.protocol}</strong>
                <span className="ticket-title">{t.title}</span>
              </td>
              <td>
                <div className="person-cell">
                  <div className="avatar">{t.initials}</div>
                  <span>
                    {t.requester}
                    <small>{t.department}</small>
                  </span>
                </div>
              </td>
              <td>
                <span className="category-chip">{t.category}</span>
              </td>
              <td>
                <PriorityBadge value={t.priority} />
              </td>
              <td>
                <StatusBadge value={t.status} />
              </td>
              <td>
                <span
                  className={`sla-text sla-${getSlaState(t).toLowerCase()}`}
                >
                  {getSlaState(t)}
                  <small>{formatDate(t.dueAt)}</small>
                </span>
              </td>
              <td>
                <ChevronRight size={17} className="row-chevron" />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {tickets.length === 0 && (
        <div className="empty-state">
          <Search size={28} />
          <strong>Nenhum chamado encontrado</strong>
          <span>Tente ajustar os filtros ou sua busca.</span>
        </div>
      )}
    </div>
  );
}
function TicketDrawer({
  ticket,
  onClose,
  onUpdate,
  onComment,
  technicians,
}: {
  ticket: TicketItem;
  onClose: () => void;
  onUpdate: (id: string, patch: Partial<TicketItem>) => void;
  onComment: (id: string, body: string) => Promise<boolean | undefined>;
  technicians: string[];
}) {
  const [message, setMessage] = useState("");
  return (
    <div className="modal-backdrop" role="presentation">
      <div className="drawer" role="dialog" aria-modal="true" aria-labelledby="ticket-drawer-title">
        <div className="drawer-head">
          <div>
            <span className="eyebrow">DETALHE DO CHAMADO</span>
            <h2 id="ticket-drawer-title">{ticket.protocol}</h2>
          </div>
          <button aria-label="Fechar detalhe do chamado" className="icon-button" onClick={onClose}>
            <X size={19} />
          </button>
        </div>
        <div className="drawer-scroll">
          <div className="drawer-title">
            <PriorityBadge value={ticket.priority} />
            <StatusBadge value={ticket.status} />
            <span
              className={`sla-pill ${getSlaState(ticket) === "Vencido" ? "danger" : ""}`}
            >
              <Clock3 size={13} /> SLA {getSlaState(ticket).toLowerCase()}
            </span>
            <h3>{ticket.title}</h3>
            <p>{ticket.description}</p>
          </div>
          <div className="detail-grid">
            <div>
              <small>SOLICITANTE</small>
              <strong>{ticket.requester}</strong>
              <span>{ticket.email}</span>
            </div>
            <div>
              <small>DEPARTAMENTO</small>
              <strong>{ticket.department}</strong>
              <span>Aberto em {formatDate(ticket.openedAt)}</span>
            </div>
            <div>
              <small>RESPONSÁVEL</small>
              <select
                value={ticket.assignee}
                onChange={e =>
                  onUpdate(ticket.id, { assignee: e.target.value })
                }
              >
                {technicians.map(t => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </div>
            <div>
              <small>PRAZO DO SLA</small>
              <strong className={isOverdue(ticket) ? "danger-text" : ""}>
                {formatDate(ticket.dueAt)}
              </strong>
              <span>Janela de {slaHours[ticket.priority]}h</span>
            </div>
          </div>
          <div className="drawer-section">
            <div className="section-title">
              <h4>Atualização operacional</h4>
              <span>Alterações salvas automaticamente</span>
            </div>
            <div className="select-row">
              <label>
                Status
                <select
                  value={ticket.status}
                  onChange={e =>
                    onUpdate(ticket.id, { status: e.target.value as Status })
                  }
                >
                  {statuses.map(s => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </label>
              <label>
                Prioridade
                <select
                  value={ticket.priority}
                  onChange={e => {
                    const p = e.target.value as Priority;
                    onUpdate(ticket.id, {
                      priority: p,
                      dueAt: addHours(new Date(ticket.openedAt), slaHours[p]),
                    });
                  }}
                >
                  {priorities.map(p => (
                    <option key={p}>{p}</option>
                  ))}
                </select>
              </label>
            </div>
          </div>
          <div className="drawer-section">
            <div className="section-title">
              <h4>Linha do tempo</h4>
              <span>{ticket.messages.length + 1} registros</span>
            </div>
            <div className="timeline">
              <div className="timeline-item">
                <div className="timeline-dot cyan-dot" />
                <div>
                  <strong>Chamado aberto por {ticket.requester}</strong>
                  <span>
                    {formatDate(ticket.openedAt)} · Solicitação registrada
                  </span>
                </div>
              </div>
              {ticket.messages.map((m, i) => (
                <div className="timeline-item" key={i}>
                  <div
                    className={`timeline-dot ${m.internal ? "amber-dot" : "purple-dot"}`}
                  />
                  <div>
                    <strong>
                      {m.author}{" "}
                      {m.internal
                        ? "· Nota interna"
                        : "· Resposta ao solicitante"}
                    </strong>
                    <span>{m.text}</span>
                    <small>{formatDate(m.date)}</small>
                  </div>
                </div>
              ))}
            </div>
            <div className="comment-box">
              <textarea
                placeholder="Adicionar atualização ao chamado..."
                value={message}
                onChange={e => setMessage(e.target.value)}
              />
              <div>
                <span>
                  <Paperclip size={15} /> Anexar arquivo
                </span>
                <button
                  onClick={() => {
                    if (!message.trim()) return;
                    void onComment(ticket.id, message).then(saved => {
                      if (saved) { setMessage(""); toast.success("Atualização adicionada"); }
                    });
                  }}
                >
                  Enviar atualização <ChevronRight size={15} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
function CreateModal({
  onClose,
  onSubmit,
}: {
  onClose: () => void;
  onSubmit: (e: FormEvent<HTMLFormElement>) => void;
}) {
  return (
    <div className="modal-backdrop" role="presentation">
      <div className="create-modal" role="dialog" aria-modal="true" aria-labelledby="create-ticket-title">
        <div className="drawer-head">
          <div>
            <span className="eyebrow">NOVA SOLICITAÇÃO</span>
            <h2 id="create-ticket-title">Abrir chamado</h2>
          </div>
          <button aria-label="Fechar formulário" className="icon-button" onClick={onClose}>
            <X size={19} />
          </button>
        </div>
        <form onSubmit={onSubmit}>
          <div className="form-grid">
            <label>
              Nome do solicitante
              <input
                name="requester"
                required
                placeholder="Ex.: Fernanda Oliveira"
              />
            </label>
            <label>
              Setor
              <input name="department" required placeholder="Ex.: Financeiro" />
            </label>
            <label>
              E-mail de contato
              <input
                name="email"
                type="email"
                required
                placeholder="nome@empresa.com"
              />
            </label>
            <label>
              Categoria
              <select name="category" defaultValue="Software">
                {categories.map(c => (
                  <option key={c}>{c}</option>
                ))}
              </select>
            </label>
            <label>
              Prioridade
              <select name="priority" defaultValue="Média">
                {priorities.map(p => (
                  <option key={p}>{p}</option>
                ))}
              </select>
            </label>
            <label className="full">
              Título do problema
              <input
                name="title"
                required
                placeholder="Descreva o problema em uma frase"
              />
            </label>
            <label className="full">
              Descrição detalhada
              <textarea
                name="description"
                required
                placeholder="Inclua contexto, mensagens de erro e impacto na operação..."
              />
            </label>
          </div>
          <div className="form-foot">
            <span>
              <Paperclip size={15} /> Você poderá anexar arquivos após criar
            </span>
            <div>
              <button type="button" className="ghost-button" onClick={onClose}>
                Cancelar
              </button>
              <button className="primary-button" type="submit">
                <Plus size={16} /> Criar chamado
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
function Reports({
  tickets,
  technicians,
  onExport,
  onExportPdf,
}: {
  tickets: TicketItem[];
  technicians: string[];
  onExport: () => void;
  onExportPdf: () => void;
}) {
  const solved = tickets.filter(t =>
    ["Resolvido", "Fechado"].includes(t.status)
  ).length;
  const resolvedDurations = tickets.filter(t => t.resolvedAt).map(t => new Date(t.resolvedAt!).getTime() - new Date(t.openedAt).getTime()).filter(value => value >= 0);
  const averageResolution = resolvedDurations.length ? `${Math.floor(resolvedDurations.reduce((sum, value) => sum + value, 0) / resolvedDurations.length / 3600000)}h ${Math.floor(resolvedDurations.reduce((sum, value) => sum + value, 0) / resolvedDurations.length / 60000) % 60}m` : "Sem dados";
  return (
    <div className="page">
      <div className="page-heading">
        <div>
          <div className="eyebrow">
            <BarChart3 size={14} /> INTELIGÊNCIA OPERACIONAL
          </div>
          <h1>Relatórios</h1>
          <p>Indicadores para acompanhar a eficiência do suporte.</p>
        </div>
        <div className="heading-actions">
          <button className="outline-button report-export" onClick={onExportPdf}>Exportar PDF</button>
          <button className="primary-button" onClick={onExport}>
            <BarChart3 size={16} /> Exportar Excel
          </button>
        </div>
      </div>
      <div className="report-cards">
        <div>
          <span>Taxa de resolução</span>
            <strong>{tickets.length ? Math.round((solved / tickets.length) * 100) : 0}%</strong>
          <small>Chamados encerrados</small>
        </div>
        <div>
          <span>Dentro do SLA</span>
          <strong>
            {tickets.length ? Math.round((tickets.filter(t => getSlaState(t) === "No prazo").length / tickets.length) * 100) : 0}
            %
          </strong>
          <small>Performance da operação</small>
        </div>
        <div>
          <span>Tempo médio</span>
            <strong>{averageResolution}</strong>
            <small>Até a resolução</small>
        </div>
      </div>
      <div className="panel report-panel">
        <div className="panel-heading">
          <div>
            <h3>Resumo dos chamados</h3>
            <span>Base atual persistida no banco</span>
          </div>
          <span className="date-filter">
            <CalendarDays size={15} /> Últimos 30 dias
          </span>
        </div>
        <div className="report-table">
          <div>
            <span>Chamados por categoria</span>
            <strong>
              {categories
                .map(
                  c => `${c}: ${tickets.filter(t => t.category === c).length}`
                )
                .join("  ·  ")}
            </strong>
          </div>
          <div>
            <span>Chamados por prioridade</span>
            <strong>
              {priorities
                .map(
                  p => `${p}: ${tickets.filter(t => t.priority === p).length}`
                )
                .join("  ·  ")}
            </strong>
          </div>
          <div>
            <span>Técnicos com chamados atribuídos</span>
            <strong>
              {technicians
                .slice(0, 3)
                .map(
                  t => `${t}: ${tickets.filter(x => x.assignee === t).length}`
                )
                .join("  ·  ")}
            </strong>
          </div>
        </div>
      </div>
    </div>
  );
}
function Settings({ technicians }: { technicians: string[] }) {
  const [categoryCount, setCategoryCount] = useState(categories.length);
  const [slaValues, setSlaValues] = useState<Record<string, number>>(slaHours);
  useEffect(() => {
    fetch("/api/config", { credentials: "include" }).then(response => response.ok ? response.json() : null).then(data => {
      if (data?.categories) setCategoryCount(data.categories.length);
      if (data?.sla) setSlaValues(Object.fromEntries(data.sla.map((item: { priority: string; resolutionMinutes: number }) => [item.priority, item.resolutionMinutes / 60])));
    }).catch(() => toast.error("Não foi possível carregar as configurações do banco"));
  }, []);
  async function editSla() {
    const priority = window.prompt("Prioridade (low, medium, high, critical)", "medium");
    if (!priority) return;
    const hours = Number(window.prompt("Prazo de resolução em horas", "24"));
    if (!Number.isFinite(hours) || hours <= 0) return toast.error("Prazo inválido");
    const response = await fetch(`/api/config/sla/${priority}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify({ responseMinutes: 60, resolutionMinutes: hours * 60, businessStart: "08:00", businessEnd: "18:00", workingDays: "1,2,3,4,5" }) });
    response.ok ? toast.success("Prazo SLA salvo no banco") : toast.error("Não foi possível salvar o SLA");
  }
  async function addCategory() {
    const name = window.prompt("Nome da nova categoria");
    if (!name) return;
    const response = await fetch("/api/config/categories", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify({ name }) });
    response.ok ? toast.success("Categoria cadastrada no banco") : toast.error("Não foi possível cadastrar a categoria");
  }
  return (
    <div className="page">
      <div className="page-heading">
        <div>
          <div className="eyebrow">
            <Settings2 size={14} /> ADMINISTRAÇÃO
          </div>
          <h1>Configurações</h1>
          <p>Parâmetros da operação SCANF Help Desk.</p>
        </div>
      </div>
      <div className="settings-grid">
        <div className="panel settings-panel">
          <div className="panel-heading">
            <div>
              <h3>Políticas de SLA</h3>
              <span>Prazos padrão por prioridade</span>
            </div>
            <ShieldCheck size={19} />
          </div>
          {priorities.map(p => (
            <div className="setting-row" key={p}>
              <div>
                <PriorityBadge value={p} />
                <span>Tempo para atendimento e resolução</span>
              </div>
              <strong>{slaValues[apiPriority[p]] ?? slaHours[p]} horas</strong>
            </div>
          ))}
          <button
            className="outline-button"
            onClick={editSla}
          >
            Editar parâmetros
          </button>
        </div>
        <div className="panel settings-panel">
          <div className="panel-heading">
            <div>
              <h3>Catálogo operacional</h3>
              <span>Itens configurados no sistema</span>
            </div>
            <SlidersHorizontal size={19} />
          </div>
          <div className="catalog-list">
            <div>
              <Headphones size={17} />
              <span>Categorias de chamados</span>
              <strong>{categoryCount}</strong>
            </div>
            <div>
              <Users size={17} />
              <span>Técnicos cadastrados</span>
              <strong>{technicians.length - 1}</strong>
            </div>
            <div>
              <CalendarDays size={17} />
              <span>Horário de atendimento</span>
              <strong>08:00 — 18:00</strong>
            </div>
            <div>
              <MessageSquare size={17} />
              <span>Canal padrão</span>
              <strong>Portal web</strong>
            </div>
          </div>
          <button
            className="outline-button"
            onClick={addCategory}
          >
            Cadastrar categoria
          </button>
        </div>
      </div>
    </div>
  );
}
