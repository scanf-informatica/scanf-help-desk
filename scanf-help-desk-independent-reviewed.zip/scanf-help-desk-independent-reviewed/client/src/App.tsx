import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Login from "./pages/Login";
import { useEffect, useState } from "react";

function Router({ user, onLogout }: { user: any; onLogout: () => void }) {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"}>{() => <Home user={user} onLogout={onLogout} />}</Route>
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  const [user, setUser] = useState<any>(undefined);
  useEffect(() => {
    fetch("/api/auth/me", { credentials: "include" }).then(response => response.json()).then(data => setUser(data.user)).catch(() => setUser(null));
  }, []);
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          {user === undefined ? <div className="auth-loading">Carregando ambiente SCANF...</div> : user ? <Router user={user} onLogout={() => { void fetch("/api/auth/logout", { method: "POST", credentials: "include" }).finally(() => setUser(null)); }} /> : <Login onAuthenticated={setUser} />}
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
