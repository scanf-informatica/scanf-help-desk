import { useCallback, useEffect, useState } from "react";

type UseAuthOptions = { redirectOnUnauthenticated?: boolean; redirectPath?: string };
export function useAuth(options?: UseAuthOptions) {
  const { redirectOnUnauthenticated = false, redirectPath = "/" } = options ?? {};
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const refresh = useCallback(async () => { setLoading(true); try { const response = await fetch("/api/auth/me", { credentials: "include" }); const data = await response.json(); setUser(data.user); } catch (reason) { setError(reason); setUser(null); } finally { setLoading(false); } }, []);
  useEffect(() => { void refresh(); }, [refresh]);
  useEffect(() => { if (!loading && redirectOnUnauthenticated && !user && window.location.pathname !== redirectPath) window.location.href = redirectPath; }, [loading, redirectOnUnauthenticated, redirectPath, user]);
  const logout = useCallback(async () => { await fetch("/api/auth/logout", { method: "POST", credentials: "include" }); setUser(null); }, []);
  return { user, loading, error, isAuthenticated: Boolean(user), refresh, logout };
}
