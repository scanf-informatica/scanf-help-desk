import type { Request } from "express";
import Redis from "ioredis";

export type AppRole = "admin" | "technician" | "requester";
export function roleForPublicRegistration(existingUserCount: number): AppRole {
  return existingUserCount === 0 ? "admin" : "requester";
}
type LoginState = {
  failures: number;
  firstFailureAt: number;
  blockedUntil: number;
};
export class LoginRateLimiter {
  private readonly attempts = new Map<string, LoginState>();
  constructor(
    private readonly maxFailures = 5,
    private readonly windowMs = 15 * 60_000,
    private readonly blockMs = 15 * 60_000
  ) {}
  canAttempt(key: string, now = Date.now()) {
    const state = this.attempts.get(key);
    if (!state) return true;
    if (state.blockedUntil > now) return false;
    if (now - state.firstFailureAt > this.windowMs) {
      this.attempts.delete(key);
      return true;
    }
    return state.failures < this.maxFailures;
  }
  recordFailure(key: string, now = Date.now()) {
    const current = this.attempts.get(key);
    const state =
      !current || now - current.firstFailureAt > this.windowMs
        ? { failures: 0, firstFailureAt: now, blockedUntil: 0 }
        : current;
    state.failures += 1;
    if (state.failures >= this.maxFailures)
      state.blockedUntil = now + this.blockMs;
    this.attempts.set(key, state);
  }
  clear(key: string) {
    this.attempts.delete(key);
  }
}
const fallbackLimiter = new LoginRateLimiter();
let redis: Redis | null = null;
function getRedis() {
  if (!process.env.REDIS_URL) return null;
  if (!redis) {
    redis = new Redis(process.env.REDIS_URL, {
      lazyConnect: true,
      maxRetriesPerRequest: 1,
      enableOfflineQueue: false,
      retryStrategy: () => null,
    });
    redis.on("error", error =>
      console.warn("[RateLimit] Redis indisponível:", error.message)
    );
  }
  return redis;
}
export class SharedLoginRateLimiter {
  constructor(
    private readonly maxFailures = 5,
    private readonly windowMs = 15 * 60_000,
    private readonly blockMs = 15 * 60_000
  ) {}
  private key(key: string) {
    return `scanf:login:${key}`;
  }
  async canAttempt(key: string) {
    const client = getRedis();
    if (!client) return fallbackLimiter.canAttempt(key);
    try {
      if (client.status === "wait") await client.connect();
      const value = await client.hgetall(this.key(key));
      const failures = Number(value.failures ?? 0);
      const first = Number(value.firstFailureAt ?? 0);
      const blocked = Number(value.blockedUntil ?? 0);
      const now = Date.now();
      if (blocked > now) return false;
      if (first && now - first > this.windowMs) {
        await client.del(this.key(key));
        return true;
      }
      return failures < this.maxFailures;
    } catch {
      return fallbackLimiter.canAttempt(key);
    }
  }
  async recordFailure(key: string) {
    const client = getRedis();
    if (!client) {
      fallbackLimiter.recordFailure(key);
      return;
    }
    try {
      if (client.status === "wait") await client.connect();
      const redisKey = this.key(key);
      const now = Date.now();
      const current = await client.hgetall(redisKey);
      const first = Number(current.firstFailureAt ?? 0);
      const within = first && now - first <= this.windowMs;
      const failures = within ? Number(current.failures ?? 0) + 1 : 1;
      await client.hset(redisKey, {
        failures: String(failures),
        firstFailureAt: String(within ? first : now),
        blockedUntil:
          failures >= this.maxFailures ? String(now + this.blockMs) : "0",
      });
      await client.pexpire(redisKey, this.windowMs + this.blockMs);
    } catch {
      fallbackLimiter.recordFailure(key);
    }
  }
  async clear(key: string) {
    const client = getRedis();
    if (!client) {
      fallbackLimiter.clear(key);
      return;
    }
    try {
      if (client.status === "wait") await client.connect();
      await client.del(this.key(key));
    } catch {
      fallbackLimiter.clear(key);
    }
  }
}
export function requestAddress(req: Request) {
  return String(
    req.headers["x-forwarded-for"] ?? req.socket.remoteAddress ?? "unknown"
  )
    .split(",")[0]
    .trim();
}
export function isSameOrigin(req: Request) {
  const candidate = req.headers.origin ?? req.headers.referer;
  if (!candidate) return false;
  const proto = String(
    req.headers["x-forwarded-proto"] ??
      (req as Request & { protocol?: string }).protocol ??
      "http"
  )
    .split(",")[0]
    .replace(/:$/, "");
  const host = String(
    req.headers["x-forwarded-host"] ?? req.headers.host ?? ""
  ).split(",")[0];
  try {
    const url = new URL(candidate);
    return url.protocol === `${proto}:` && url.host === host;
  } catch {
    return false;
  }
}
