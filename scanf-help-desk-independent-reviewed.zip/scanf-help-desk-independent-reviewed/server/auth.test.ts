import { describe, expect, it } from "vitest";
import { AUTH_COOKIE, destroySession, hashPassword, verifyPassword } from "./auth";

describe("SCANF own authentication", () => {
  it("hashes passwords and rejects wrong credentials", () => {
    const hash = hashPassword("senha-segura-123");
    expect(hash).not.toContain("senha-segura-123");
    expect(verifyPassword("senha-segura-123", hash)).toBe(true);
    expect(verifyPassword("outra-senha", hash)).toBe(false);
  });

  it("logout clears only the own SCANF session cookie", async () => {
    const cleared: string[] = [];
    await destroySession({ cookies: {} } as any, { clearCookie: (name: string) => cleared.push(name) } as any);
    expect(cleared).toEqual([AUTH_COOKIE]);
  });
});
