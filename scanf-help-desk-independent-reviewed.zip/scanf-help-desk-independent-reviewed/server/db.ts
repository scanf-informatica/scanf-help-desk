import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from './_core/env';

type LegacyUserInput = Partial<InsertUser> & { openId?: string | null; name?: string | null; email?: string | null; loginMethod?: string | null };

let _db: ReturnType<typeof drizzle> | null = null;
export async function getDb() {
  if (!_db && ENV.databaseUrl) {
    try { _db = drizzle(ENV.databaseUrl); } catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}
export async function upsertUser(user: LegacyUserInput): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values: InsertUser = { ...user, openId: user.openId ?? undefined, email: user.email ?? `${user.openId ?? "user"}@manus.local`, name: user.name ?? "Usuário SCANF" };
  const updateSet: Record<string, unknown> = { name: values.name, email: values.email, lastSignedIn: new Date() };
  if (user.role) updateSet.role = user.role;
  await db.insert(users).values({ ...values, lastSignedIn: new Date() }).onDuplicateKeyUpdate({ set: updateSet });
}
export async function getUserByOpenId(openId: string) { const db = await getDb(); if (!db) return undefined; const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1); return result[0]; }
