import { randomUUID } from "node:crypto";
import { GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const bucket = process.env.S3_BUCKET ?? "";
const client = process.env.S3_ENDPOINT && process.env.S3_ACCESS_KEY_ID && process.env.S3_SECRET_ACCESS_KEY
  ? new S3Client({ region: process.env.S3_REGION ?? "us-east-1", endpoint: process.env.S3_ENDPOINT, forcePathStyle: process.env.S3_FORCE_PATH_STYLE !== "false", credentials: { accessKeyId: process.env.S3_ACCESS_KEY_ID, secretAccessKey: process.env.S3_SECRET_ACCESS_KEY } })
  : null;

export function storageConfigured() { return Boolean(client && bucket); }
export async function uploadObject(key: string, body: Buffer, contentType: string) {
  if (!client || !bucket) throw new Error("STORAGE_NOT_CONFIGURED");
  await client.send(new PutObjectCommand({ Bucket: bucket, Key: key, Body: body, ContentType: contentType }));
}
export async function signedUploadUrl(key: string, contentType: string) {
  if (!client || !bucket) throw new Error("STORAGE_NOT_CONFIGURED");
  return getSignedUrl(client, new PutObjectCommand({ Bucket: bucket, Key: key, ContentType: contentType }), { expiresIn: 900 });
}
export async function signedDownloadUrl(key: string) {
  if (!client || !bucket) throw new Error("STORAGE_NOT_CONFIGURED");
  return getSignedUrl(client, new GetObjectCommand({ Bucket: bucket, Key: key }), { expiresIn: 900 });
}

export async function storagePut(relKey: string, data: Buffer | Uint8Array | string, contentType = "application/octet-stream") {
  const normalized = relKey.replace(/^\/+/, "");
  const key = normalized.replace(/(\.[^./]+)$/, `-${randomUUID().replace(/-/g, "").slice(0, 8)}$1`);
  const body = Buffer.isBuffer(data) ? data : Buffer.from(data);
  await uploadObject(key, body, contentType);
  return { key, url: key };
}
