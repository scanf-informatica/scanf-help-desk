import {
  createHash,
  randomBytes,
  scryptSync,
  timingSafeEqual,
} from "node:crypto";
import type { Request, Response } from "express";
import { and, eq, gt } from "drizzle-orm";
import { appSessions, users, type User } from "../drizzle/schema";
import { getDb } from "./db";

export const AUTH_COOKIE = "scanf_session";
const SESSION_DAYS = 7;

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string) {
  const [salt, expected] = stored.split(":");
  if (!salt || !expected) return false;
  const actual = scryptSync(password, salt, 64);
  return timingSafeEqual(actual, Buffer.from(expected, "hex"));
}

function sessionId() {
  return randomBytes(48).toString("base64url");
}
function sessionCookieOptions(res?: Response) {
  const forwarded = String(res?.req?.headers["x-forwarded-proto"] ?? "")
    .split(",")[0]
    .trim();
  const publicHttps =
    forwarded === "https" ||
    (process.env.NODE_ENV === "production" &&
      process.env.COOKIE_SECURE !== "false");
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: publicHttps,
    path: "/",
    maxAge: SESSION_DAYS * 86400000,
  };
}

export async function createSession(userId: number, res: Response) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_NOT_CONFIGURED");
  const id = sessionId();
  await db
    .insert(appSessions)
    .values({
      id,
      userId,
      expiresAt: new Date(Date.now() + SESSION_DAYS * 86400000),
    });
  res.cookie(AUTH_COOKIE, id, sessionCookieOptions(res));
}

export async function destroySession(req: Request, res: Response) {
  const id = req.cookies?.[AUTH_COOKIE];
  const db = await getDb();
  if (id && db) await db.delete(appSessions).where(eq(appSessions.id, id));
  res.clearCookie(AUTH_COOKIE, {
    ...sessionCookieOptions(res),
    maxAge: undefined,
  });
}

export async function currentUser(req: Request): Promise<User | null> {
  const id = req.cookies?.[AUTH_COOKIE];
  if (!id) return null;
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select({ user: users })
    .from(appSessions)
    .innerJoin(users, eq(appSessions.userId, users.id))
    .where(
      and(
        eq(appSessions.id, id),
        gt(appSessions.expiresAt, new Date()),
        eq(users.active, true)
      )
    )
    .limit(1);
  return result[0]?.user ?? null;
}

export function publicUser(user: User) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    departmentId: user.departmentId,
  };
}
export function tokenHash(token: string) {
  return createHash("sha256").update(token).digest("hex");
}
