import { describe, expect, it } from "vitest";
import { isSameOrigin, LoginRateLimiter, roleForPublicRegistration } from "./security";
import { canReadTicket } from "./fullstackRoutes";

describe("SCANF security rules", () => {
  it("creates only the first public account as admin", () => {
    expect(roleForPublicRegistration(0)).toBe("admin");
    expect(roleForPublicRegistration(1)).toBe("requester");
    expect(roleForPublicRegistration(99)).toBe("requester");
  });

  it("blocks excessive login attempts and resets after a successful login", () => {
    const limiter = new LoginRateLimiter(3, 1_000, 10_000);
    expect(limiter.canAttempt("ip:a")).toBe(true);
    limiter.recordFailure("ip:a", 100); limiter.recordFailure("ip:a", 200); limiter.recordFailure("ip:a", 300);
    expect(limiter.canAttempt("ip:a", 400)).toBe(false);
    limiter.clear("ip:a");
    expect(limiter.canAttempt("ip:a", 400)).toBe(true);
  });

  it("accepts same-origin mutation and rejects a different origin", () => {
    const base = { protocol: "http:", headers: { origin: "http://localhost:3000", host: "localhost:3000" }, socket: { remoteAddress: "127.0.0.1" } } as any;
    expect(isSameOrigin(base)).toBe(true);
    expect(isSameOrigin({ ...base, headers: { ...base.headers, origin: "https://evil.example" } } as any)).toBe(false);
  });

  it("isolates requester tickets and limits technicians to assigned/unassigned work", async () => {
    const requester = { id: 10, role: "requester" } as any;
    const technician = { id: 20, role: "technician" } as any;
    const own = { requesterId: 10, assigneeId: 20 };
    const other = { requesterId: 11, assigneeId: 20 };
    const unassigned = { requesterId: 11, assigneeId: null };
    expect(await canReadTicket(requester, own)).toBe(true);
    expect(await canReadTicket(requester, other)).toBe(false);
    expect(await canReadTicket(technician, own)).toBe(true);
    expect(await canReadTicket(technician, unassigned)).toBe(true);
  });
});
