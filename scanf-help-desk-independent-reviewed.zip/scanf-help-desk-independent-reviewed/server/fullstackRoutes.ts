import { randomBytes } from "node:crypto";
import { and, asc, desc, eq, gt, like, or, sql } from "drizzle-orm";
import type { Express, Request, Response } from "express";
import { z } from "zod";
import {
  appSessions,
  attachments,
  categories,
  comments,
  departments,
  slaConfigs,
  ticketHistory,
  tickets,
  users,
} from "../drizzle/schema";
import {
  createSession,
  currentUser,
  destroySession,
  hashPassword,
  publicUser,
  tokenHash,
  verifyPassword,
} from "./auth";
import { getDb } from "./db";
import {
  isSameOrigin,
  requestAddress,
  roleForPublicRegistration,
} from "./security";
import {
  signedDownloadUrl,
  signedUploadUrl,
  storageConfigured,
  uploadObject,
} from "./storage";
import { sendPasswordResetEmail } from "./email";
import { MAX_ATTACHMENT_BYTES, validateAttachment } from "./fileValidation";
import { SharedLoginRateLimiter } from "./security";

const priorityMap = {
  low: "low",
  medium: "medium",
  high: "high",
  critical: "critical",
} as const;
const registerSchema = z.object({
  name: z.string().min(2).max(180),
  email: z.string().email(),
  password: z.string().min(8),
  departmentId: z.number().int().positive().optional(),
});
const managedUserSchema = registerSchema.extend({
  role: z.enum(["admin", "technician"]),
});
const ticketSchema = z.object({
  title: z.string().min(3).max(240),
  description: z.string().min(3),
  categoryId: z.number().int().positive().optional(),
  category: z.string().optional(),
  departmentId: z.number().int().positive().optional(),
  priority: z.enum(["low", "medium", "high", "critical"]).default("medium"),
});
const commentSchema = z.object({
  body: z.string().min(1),
  internal: z.boolean().default(false),
});

function sendError(res: Response, status: number, message: string) {
  return res.status(status).json({ error: message });
}
async function requireUser(req: Request, res: Response) {
  const user = await currentUser(req);
  if (!user) {
    sendError(res, 401, "AUTH_REQUIRED");
    return null;
  }
  return user;
}
export async function canReadTicket(
  user: Awaited<ReturnType<typeof currentUser>>,
  ticket: { requesterId: number; assigneeId: number | null }
) {
  return (
    !!user &&
    (user.role === "admin" ||
      (user.role === "technician" &&
        (!ticket.assigneeId || ticket.assigneeId === user.id)) ||
      (user.role === "requester" && ticket.requesterId === user.id))
  );
}
function protocol() {
  return `#SCF-${Date.now().toString().slice(-7)}`;
}
function dueAt(priority: keyof typeof priorityMap) {
  const hours = { low: 48, medium: 24, high: 8, critical: 2 }[priority];
  return new Date(Date.now() + hours * 3600000);
}
function parseCookies(req: Request) {
  const raw = req.headers.cookie ?? "";
  return Object.fromEntries(
    raw
      .split(";")
      .filter(Boolean)
      .map(p => {
        const i = p.indexOf("=");
        try {
          return [
            p.slice(0, i).trim(),
            decodeURIComponent(p.slice(i + 1).trim()),
          ];
        } catch {
          return [p.slice(0, i).trim(), ""];
        }
      })
  );
}
function simplePdf(lines: string[]) {
  const safe = lines.map(line => line.replace(/[()\\]/g, "\\$&").slice(0, 110));
  const content = [
    "BT",
    "/F1 10 Tf",
    "50 780 Td",
    ...safe.flatMap((line, index) => [index ? "0 -16 Td" : "", `(${line}) Tj`]),
    "ET",
  ]
    .filter(Boolean)
    .join("\n");
  const objects = [
    `1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj`,
    `2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj`,
    `3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >> endobj`,
    `4 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj`,
    `5 0 obj << /Length ${Buffer.byteLength(content)} >> stream\n${content}\nendstream endobj`,
  ];
  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  for (const object of objects) {
    offsets.push(Buffer.byteLength(pdf));
    pdf += `${object}\n`;
  }
  const xref = Buffer.byteLength(pdf);
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n${offsets
    .slice(1)
    .map(offset => String(offset).padStart(10, "0") + " 00000 n ")
    .join(
      "\n"
    )}\ntrailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return Buffer.from(pdf);
}
const loginLimiter = new SharedLoginRateLimiter();

export function registerFullstackRoutes(app: Express) {
  app.use((req, res, next) => {
    (req as Request & { cookies?: Record<string, string> }).cookies =
      parseCookies(req);
    if (
      ["POST", "PUT", "PATCH", "DELETE"].includes(req.method) &&
      !isSameOrigin(req)
    )
      return sendError(res, 403, "CSRF_BLOCKED");
    next();
  });

  app.get("/api/auth/me", async (req, res) => {
    const user = await currentUser(req);
    res.json({ user: user ? publicUser(user) : null });
  });
  app.post("/api/auth/register", async (req, res) => {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) return sendError(res, 400, "INVALID_REGISTRATION");
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    try {
      const created = await db.transaction(async tx => {
        const lock = await tx.execute(
          sql`SELECT GET_LOCK('scanf_first_admin', 10) AS locked`
        );
        if (Number((lock as any)[0]?.locked ?? 0) !== 1)
          throw new Error("FIRST_ADMIN_LOCK_UNAVAILABLE");
        try {
          const email = parsed.data.email.toLowerCase();
          const existing = await tx
            .select({ id: users.id })
            .from(users)
            .where(eq(users.email, email))
            .limit(1);
          if (existing[0]) throw new Error("EMAIL_ALREADY_REGISTERED");
          const count = await tx
            .select({ count: sql<number>`count(*)` })
            .from(users);
          const role = roleForPublicRegistration(Number(count[0]?.count ?? 0));
          const result = await tx.insert(users).values({
            name: parsed.data.name,
            email,
            passwordHash: hashPassword(parsed.data.password),
            role,
            departmentId: parsed.data.departmentId,
          });
          const userId = Number(result[0].insertId);
          const createdUser = (
            await tx.select().from(users).where(eq(users.id, userId)).limit(1)
          )[0];
          return { userId, user: createdUser };
        } finally {
          await tx.execute(sql`SELECT RELEASE_LOCK('scanf_first_admin')`);
        }
      });
      await createSession(created.userId, res);
      res.status(201).json({ user: publicUser(created.user) });
    } catch (error) {
      if (
        error instanceof Error &&
        error.message === "EMAIL_ALREADY_REGISTERED"
      )
        return sendError(res, 409, error.message);
      if (
        error instanceof Error &&
        error.message === "FIRST_ADMIN_LOCK_UNAVAILABLE"
      )
        return sendError(res, 503, error.message);
      throw error;
    }
  });
  app.post("/api/auth/login", async (req, res) => {
    const email = String(req.body?.email ?? "").toLowerCase();
    const password = String(req.body?.password ?? "");
    const rateKey = `${requestAddress(req)}:${email}`;
    if (!(await loginLimiter.canAttempt(rateKey)))
      return sendError(res, 429, "TOO_MANY_LOGIN_ATTEMPTS");
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const found = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);
    const user = found[0];
    if (
      !user?.passwordHash ||
      !user.active ||
      !verifyPassword(password, user.passwordHash)
    ) {
      await loginLimiter.recordFailure(rateKey);
      return sendError(res, 401, "INVALID_CREDENTIALS");
    }
    await loginLimiter.clear(rateKey);
    await db
      .update(users)
      .set({ lastSignedIn: new Date() })
      .where(eq(users.id, user.id));
    await createSession(user.id, res);
    res.json({ user: publicUser(user) });
  });
  app.post("/api/auth/logout", async (req, res) => {
    await destroySession(req, res);
    res.json({ ok: true });
  });
  app.post("/api/auth/forgot-password", async (req, res) => {
    const email = String(req.body?.email ?? "").toLowerCase();
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const found = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.email, email))
      .limit(1);
    if (!found[0]) return res.json({ ok: true });
    const token = randomBytes(32).toString("hex");
    await db
      .update(users)
      .set({
        resetTokenHash: tokenHash(token),
        resetTokenExpiresAt: new Date(Date.now() + 3600000),
      })
      .where(eq(users.id, found[0].id));
    try {
      await sendPasswordResetEmail(email, token);
    } catch (error) {
      if (process.env.NODE_ENV !== "production")
        console.warn(
          "[Auth] SMTP não configurado:",
          error instanceof Error ? error.message : error
        );
    }
    res.json({ ok: true });
  });

  app.post("/api/auth/reset-password", async (req, res) => {
    const token = String(req.body?.token ?? "");
    const password = String(req.body?.password ?? "");
    if (!/^[a-f0-9]{64}$/i.test(token) || password.length < 8)
      return sendError(res, 400, "INVALID_PASSWORD_RESET");
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const found = await db
      .select({ id: users.id })
      .from(users)
      .where(
        and(
          eq(users.resetTokenHash, tokenHash(token)),
          gt(users.resetTokenExpiresAt, new Date())
        )
      )
      .limit(1);
    if (!found[0]) return sendError(res, 400, "INVALID_OR_EXPIRED_RESET");
    await db
      .update(users)
      .set({
        passwordHash: hashPassword(password),
        resetTokenHash: null,
        resetTokenExpiresAt: null,
      })
      .where(eq(users.id, found[0].id));
    await db.delete(appSessions).where(eq(appSessions.userId, found[0].id));
    res.json({ ok: true });
  });
  app.get("/api/tickets", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user) return;
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const conditions = [
      user.role === "requester"
        ? eq(tickets.requesterId, user.id)
        : user.role === "technician"
          ? or(
              eq(tickets.assigneeId, user.id),
              sql`${tickets.assigneeId} IS NULL`
            )
          : undefined,
    ].filter(Boolean) as any[];
    const rows = await db
      .select({
        ticket: tickets,
        requester: users,
        category: categories,
        department: departments,
      })
      .from(tickets)
      .innerJoin(users, eq(tickets.requesterId, users.id))
      .leftJoin(categories, eq(tickets.categoryId, categories.id))
      .leftJoin(departments, eq(tickets.departmentId, departments.id))
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(desc(tickets.updatedAt));
    res.json({
      tickets: rows.map(row => ({
        ...row.ticket,
        requester: {
          id: row.requester.id,
          name: row.requester.name,
          email: row.requester.email,
        },
        category: row.category,
        department: row.department,
      })),
    });
  });
  app.post("/api/tickets", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user) return;
    const parsed = ticketSchema.safeParse(req.body);
    if (!parsed.success) return sendError(res, 400, "INVALID_TICKET");
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const input = parsed.data;
    const categoryId =
      input.categoryId ??
      (input.category
        ? (
            await db
              .select({ id: categories.id })
              .from(categories)
              .where(eq(categories.name, input.category))
              .limit(1)
          )[0]?.id
        : undefined);
    const result = await db.insert(tickets).values({
      protocol: protocol(),
      requesterId: user.id,
      title: input.title,
      description: input.description,
      categoryId,
      departmentId: input.departmentId,
      priority: input.priority,
      slaDueAt: dueAt(input.priority),
    });
    const id = Number(result[0].insertId);
    await db.insert(ticketHistory).values({
      ticketId: id,
      actorId: user.id,
      action: "created",
      description: "Chamado criado",
    });
    const created = await db
      .select()
      .from(tickets)
      .where(eq(tickets.id, id))
      .limit(1);
    res.status(201).json({ ticket: created[0] });
  });
  app.patch("/api/tickets/:id", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user) return;
    const id = Number(req.params.id);
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const found = await db
      .select()
      .from(tickets)
      .where(eq(tickets.id, id))
      .limit(1);
    const ticket = found[0];
    if (
      !ticket ||
      !(await canReadTicket(user, ticket)) ||
      user.role === "requester"
    )
      return sendError(res, 403, "FORBIDDEN");
    const parsedPatch = z
      .object({
        status: z
          .enum([
            "open",
            "analyzing",
            "in_progress",
            "waiting_requester",
            "waiting_third_party",
            "resolved",
            "closed",
          ])
          .optional(),
        priority: z.enum(["low", "medium", "high", "critical"]).optional(),
        assigneeId: z.number().int().positive().nullable().optional(),
        assigneeName: z.string().optional(),
      })
      .safeParse(req.body);
    if (!parsedPatch.success)
      return sendError(res, 400, "INVALID_TICKET_UPDATE");
    const patch = parsedPatch.data;
    const resolvedAssignee = patch.assigneeName
      ? ((
          await db
            .select({ id: users.id })
            .from(users)
            .where(
              and(
                eq(users.name, patch.assigneeName),
                eq(users.role, "technician")
              )
            )
            .limit(1)
        )[0]?.id ?? null)
      : patch.assigneeId;
    const dbPatch = {
      status: patch.status,
      priority: patch.priority,
      assigneeId: resolvedAssignee,
      resolvedAt:
        patch.status === "resolved" || patch.status === "closed"
          ? new Date()
          : undefined,
      firstResponseAt:
        patch.status && !["open", "waiting_requester"].includes(patch.status)
          ? (ticket.firstResponseAt ?? new Date())
          : undefined,
      slaDueAt: patch.priority ? dueAt(patch.priority) : undefined,
    };
    const description = Object.entries({
      ...dbPatch,
      assigneeName: patch.assigneeName,
    })
      .filter(([, value]) => value !== undefined)
      .map(([key, value]) => `${key}: ${value ?? "sem atribuição"}`)
      .join(", ");
    await db.update(tickets).set(dbPatch).where(eq(tickets.id, id));
    await db.insert(ticketHistory).values({
      ticketId: id,
      actorId: user.id,
      action: "updated",
      description,
    });
    const updated = await db
      .select()
      .from(tickets)
      .where(eq(tickets.id, id))
      .limit(1);
    res.json({ ticket: updated[0] });
  });
  app.get("/api/tickets/:id", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user) return;
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const id = Number(req.params.id);
    const ticket = (
      await db.select().from(tickets).where(eq(tickets.id, id)).limit(1)
    )[0];
    if (!ticket || !(await canReadTicket(user, ticket)))
      return sendError(res, 404, "NOT_FOUND");
    const [history, ticketComments, ticketAttachments] = await Promise.all([
      db
        .select()
        .from(ticketHistory)
        .where(eq(ticketHistory.ticketId, id))
        .orderBy(asc(ticketHistory.createdAt)),
      db
        .select()
        .from(comments)
        .where(
          and(
            eq(comments.ticketId, id),
            user.role === "requester"
              ? eq(comments.internal, false)
              : (undefined as any)
          )
        )
        .orderBy(asc(comments.createdAt)),
      db.select().from(attachments).where(eq(attachments.ticketId, id)),
    ]);
    res.json({
      ticket,
      history,
      comments: ticketComments,
      attachments: ticketAttachments,
    });
  });
  app.post("/api/tickets/:id/comments", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user) return;
    const parsed = commentSchema.safeParse(req.body);
    if (!parsed.success) return sendError(res, 400, "INVALID_COMMENT");
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const id = Number(req.params.id);
    const ticket = (
      await db.select().from(tickets).where(eq(tickets.id, id)).limit(1)
    )[0];
    if (
      !ticket ||
      !(await canReadTicket(user, ticket)) ||
      (parsed.data.internal && user.role === "requester")
    )
      return sendError(res, 403, "FORBIDDEN");
    const result = await db.insert(comments).values({
      ticketId: id,
      authorId: user.id,
      body: parsed.data.body,
      internal: parsed.data.internal,
    });
    await db.insert(ticketHistory).values({
      ticketId: id,
      actorId: user.id,
      action: parsed.data.internal ? "internal_note" : "comment",
      description: parsed.data.internal
        ? "Nota interna adicionada"
        : "Resposta adicionada",
    });
    res.status(201).json({ commentId: Number(result[0].insertId) });
  });

  app.get("/api/config", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user) return;
    if (user.role !== "admin") return sendError(res, 403, "FORBIDDEN");
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const [allCategories, allDepartments, sla] = await Promise.all([
      db.select().from(categories).orderBy(asc(categories.name)),
      db.select().from(departments).orderBy(asc(departments.name)),
      db.select().from(slaConfigs),
    ]);
    res.json({ categories: allCategories, departments: allDepartments, sla });
  });
  app.get("/api/technicians", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user) return;
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const rows = await db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        departmentId: users.departmentId,
        active: users.active,
      })
      .from(users)
      .where(and(eq(users.role, "technician"), eq(users.active, true)))
      .orderBy(asc(users.name));
    res.json({ technicians: rows });
  });
  app.post("/api/config/departments", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user || user.role !== "admin") return sendError(res, 403, "FORBIDDEN");
    const parsed = z.string().min(2).max(120).safeParse(req.body?.name);
    if (!parsed.success) return sendError(res, 400, "INVALID_DEPARTMENT");
    const name = parsed.data;
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const result = await db.insert(departments).values({ name });
    res.status(201).json({ id: Number(result[0].insertId), name });
  });
  app.patch("/api/config/departments/:id", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user || user.role !== "admin") return sendError(res, 403, "FORBIDDEN");
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const parsed = z
      .object({
        name: z.string().min(2).max(120).optional(),
        active: z.boolean().optional(),
      })
      .safeParse(req.body);
    if (!parsed.success) return sendError(res, 400, "INVALID_DEPARTMENT");
    await db
      .update(departments)
      .set(parsed.data)
      .where(eq(departments.id, Number(req.params.id)));
    res.json({ ok: true });
  });
  app.post("/api/config/categories", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user || user.role !== "admin") return sendError(res, 403, "FORBIDDEN");
    const parsed = z.string().min(2).max(80).safeParse(req.body?.name);
    if (!parsed.success) return sendError(res, 400, "INVALID_CATEGORY");
    const name = parsed.data;
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const result = await db.insert(categories).values({ name });
    res.status(201).json({ id: Number(result[0].insertId), name });
  });
  app.patch("/api/config/categories/:id", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user || user.role !== "admin") return sendError(res, 403, "FORBIDDEN");
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const parsed = z
      .object({
        name: z.string().min(2).max(80).optional(),
        active: z.boolean().optional(),
      })
      .safeParse(req.body);
    if (!parsed.success) return sendError(res, 400, "INVALID_CATEGORY");
    await db
      .update(categories)
      .set(parsed.data)
      .where(eq(categories.id, Number(req.params.id)));
    res.json({ ok: true });
  });
  app.post("/api/config/technicians", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user || user.role !== "admin") return sendError(res, 403, "FORBIDDEN");
    const parsed = registerSchema
      .extend({ role: z.literal("technician") })
      .safeParse(req.body);
    if (!parsed.success) return sendError(res, 400, "INVALID_TECHNICIAN");
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const result = await db.insert(users).values({
      name: parsed.data.name,
      email: parsed.data.email.toLowerCase(),
      passwordHash: hashPassword(parsed.data.password),
      role: "technician",
      departmentId: parsed.data.departmentId,
    });
    res.status(201).json({
      id: Number(result[0].insertId),
      name: parsed.data.name,
      email: parsed.data.email,
    });
  });
  app.post("/api/config/users", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user || user.role !== "admin") return sendError(res, 403, "FORBIDDEN");
    const parsed = managedUserSchema.safeParse(req.body);
    if (!parsed.success) return sendError(res, 400, "INVALID_MANAGED_USER");
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const existing = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.email, parsed.data.email.toLowerCase()))
      .limit(1);
    if (existing[0]) return sendError(res, 409, "EMAIL_ALREADY_REGISTERED");
    const result = await db.insert(users).values({
      name: parsed.data.name,
      email: parsed.data.email.toLowerCase(),
      passwordHash: hashPassword(parsed.data.password),
      role: parsed.data.role,
      departmentId: parsed.data.departmentId,
    });
    res.status(201).json({
      id: Number(result[0].insertId),
      name: parsed.data.name,
      email: parsed.data.email,
      role: parsed.data.role,
    });
  });
  app.patch("/api/config/sla/:priority", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user) return;
    if (user.role !== "admin") return sendError(res, 403, "FORBIDDEN");
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const priority = req.params.priority as keyof typeof priorityMap;
    const parsed = z
      .object({
        responseMinutes: z.number().int().positive(),
        resolutionMinutes: z.number().int().positive(),
        businessStart: z.string().regex(/^\d{2}:\d{2}$/),
        businessEnd: z.string().regex(/^\d{2}:\d{2}$/),
        workingDays: z.string(),
      })
      .safeParse(req.body);
    if (!parsed.success) return sendError(res, 400, "INVALID_SLA");
    const values = parsed.data;
    await db
      .update(slaConfigs)
      .set(values)
      .where(eq(slaConfigs.priority, priority));
    res.json({ ok: true });
  });
  app.get("/api/dashboard", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user) return;
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const rows = await db
      .select({
        status: tickets.status,
        priority: tickets.priority,
        categoryId: tickets.categoryId,
      })
      .from(tickets);
    res.json({
      total: rows.length,
      open: rows.filter(t => t.status === "open").length,
      inProgress: rows.filter(t =>
        [
          "analyzing",
          "in_progress",
          "waiting_requester",
          "waiting_third_party",
        ].includes(t.status)
      ).length,
      resolved: rows.filter(t => ["resolved", "closed"].includes(t.status))
        .length,
      byPriority: priorityMap,
      generatedAt: new Date().toISOString(),
    });
  });
  app.get("/api/reports.csv", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user) return;
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const rows = await db
      .select()
      .from(tickets)
      .where(
        user.role === "requester"
          ? eq(tickets.requesterId, user.id)
          : user.role === "technician"
            ? or(
                eq(tickets.assigneeId, user.id),
                sql`${tickets.assigneeId} IS NULL`
              )
            : undefined
      );
    const csv = [
      ["Protocolo", "Título", "Prioridade", "Status", "Abertura", "SLA"],
      ...rows.map(t => [
        t.protocol,
        t.title,
        t.priority,
        t.status,
        t.createdAt.toISOString(),
        t.slaDueAt?.toISOString() ?? "",
      ]),
    ]
      .map(row =>
        row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(",")
      )
      .join("\n");
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader(
      "Content-Disposition",
      "attachment; filename=scanf-help-desk.csv"
    );
    res.send(csv);
  });
  app.get("/api/reports.pdf", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user) return;
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const rows = await db
      .select()
      .from(tickets)
      .where(
        user.role === "requester"
          ? eq(tickets.requesterId, user.id)
          : user.role === "technician"
            ? or(
                eq(tickets.assigneeId, user.id),
                sql`${tickets.assigneeId} IS NULL`
              )
            : undefined
      );
    const pdf = simplePdf([
      "SCANF Help Desk — Relatório de chamados",
      `Gerado em ${new Date().toLocaleString("pt-BR")}`,
      `Total de chamados: ${rows.length}`,
      ...rows
        .slice(0, 40)
        .map(t => `${t.protocol} | ${t.priority} | ${t.status} | ${t.title}`),
    ]);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      "attachment; filename=scanf-help-desk.pdf"
    );
    res.send(pdf);
  });

  app.post("/api/tickets/:id/attachments/presign", async (_req, res) => {
    return sendError(res, 410, "DIRECT_UPLOAD_DISABLED_USE_VALIDATED_UPLOAD");
  });
  app.post("/api/tickets/:id/attachments/upload", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user) return;
    if (!storageConfigured())
      return sendError(res, 503, "STORAGE_NOT_CONFIGURED");
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const file = z
      .object({
        name: z.string().min(1).max(255),
        type: z.string().min(1).max(120),
        dataBase64: z.string().min(1),
      })
      .safeParse(req.body);
    if (!file.success) return sendError(res, 400, "INVALID_FILE");
    if (
      !/^[A-Za-z0-9+/]+={0,2}$/.test(file.data.dataBase64) ||
      file.data.dataBase64.length % 4 === 1
    )
      return sendError(res, 400, "INVALID_FILE_ENCODING");
    const bytes = Buffer.from(file.data.dataBase64, "base64");
    if (bytes.byteLength > MAX_ATTACHMENT_BYTES)
      return sendError(res, 413, "FILE_TOO_LARGE");
    const validation = await validateAttachment(
      bytes,
      file.data.type,
      file.data.name
    );
    if (!validation.ok)
      return sendError(
        res,
        validation.error === "FILE_TOO_LARGE" ? 413 : 415,
        validation.error
      );
    const id = Number(req.params.id);
    const ticket = (
      await db.select().from(tickets).where(eq(tickets.id, id)).limit(1)
    )[0];
    if (!ticket || !(await canReadTicket(user, ticket)))
      return sendError(res, 403, "FORBIDDEN");
    const allowed = [
      "image/",
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument",
    ].some(prefix => file.data.type.startsWith(prefix));
    if (!allowed) return sendError(res, 415, "FILE_TYPE_NOT_ALLOWED");
    const storageKey = `scanf/tickets/${id}/${Date.now()}-${randomBytes(8).toString("hex")}-${file.data.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
    await uploadObject(storageKey, bytes, validation.mimeType);
    await db.insert(attachments).values({
      ticketId: id,
      uploadedById: user.id,
      originalName: file.data.name,
      storageKey,
      mimeType: validation.mimeType,
      sizeBytes: bytes.byteLength,
    });
    res.status(201).json({ stableKey: storageKey });
  });
  app.get("/api/attachments/:id/download", async (req, res) => {
    const user = await requireUser(req, res);
    if (!user) return;
    const db = await getDb();
    if (!db) return sendError(res, 503, "DATABASE_NOT_CONFIGURED");
    const file = (
      await db
        .select({ attachment: attachments, ticket: tickets })
        .from(attachments)
        .innerJoin(tickets, eq(attachments.ticketId, tickets.id))
        .where(eq(attachments.id, Number(req.params.id)))
        .limit(1)
    )[0];
    if (!file || !(await canReadTicket(user, file.ticket)))
      return sendError(res, 404, "NOT_FOUND");
    if (!storageConfigured())
      return sendError(res, 503, "STORAGE_NOT_CONFIGURED");
    const url = await signedDownloadUrl(file.attachment.storageKey);
    res.redirect(302, url);
  });
}
