import nodemailer, { type Transporter } from "nodemailer";

let transporter: Transporter | null = null;
function getTransporter() {
  if (
    !process.env.SMTP_HOST ||
    !process.env.SMTP_USER ||
    !process.env.SMTP_PASSWORD
  )
    return null;
  transporter ??= nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT ?? 587),
    secure: process.env.SMTP_SECURE === "true",
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD },
  });
  return transporter;
}
export async function sendPasswordResetEmail(to: string, token: string) {
  const transport = getTransporter();
  if (!transport) throw new Error("SMTP_NOT_CONFIGURED");
  const baseUrl = (process.env.PUBLIC_APP_URL ?? "").replace(/\/$/, "");
  const resetUrl = `${baseUrl}/reset-password?token=${encodeURIComponent(token)}`;
  await transport.sendMail({
    from: process.env.SMTP_FROM ?? process.env.SMTP_USER,
    to,
    subject: "Recuperação de acesso — SCANF Help Desk",
    text: `Use este link para redefinir sua senha: ${resetUrl}\nO link expira em 1 hora.`,
    html: `<p>Use este link para redefinir sua senha:</p><p><a href="${resetUrl}">${resetUrl}</a></p><p>O link expira em 1 hora.</p>`,
  });
}
export function emailConfigured() {
  return Boolean(
    process.env.SMTP_HOST &&
      process.env.SMTP_USER &&
      process.env.SMTP_PASSWORD &&
      process.env.PUBLIC_APP_URL
  );
}
