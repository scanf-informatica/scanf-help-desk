import { fileTypeFromBuffer } from "file-type";

export const MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024;
const allowedMime = new Set([
  "application/pdf",
  "image/jpeg",
  "image/png",
  "image/gif",
  "image/webp",
  "application/zip",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
]);
export async function validateAttachment(
  bytes: Buffer,
  declaredType: string,
  name: string
) {
  if (!bytes.length || bytes.length > MAX_ATTACHMENT_BYTES)
    return { ok: false as const, error: "FILE_TOO_LARGE" };
  const detected = await fileTypeFromBuffer(bytes);
  const isPdf = bytes.subarray(0, 5).toString() === "%PDF-";
  const isDocx = detected?.mime === "application/zip" && /\.docx$/i.test(name);
  const detectedMime = isPdf
    ? "application/pdf"
    : isDocx
      ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      : detected?.mime;
  if (
    !detectedMime ||
    !allowedMime.has(detectedMime) ||
    !allowedMime.has(declaredType) ||
    (declaredType !== detectedMime &&
      !(declaredType === "application/zip" && isDocx))
  )
    return { ok: false as const, error: "FILE_CONTENT_NOT_ALLOWED" };
  return { ok: true as const, mimeType: detectedMime };
}
