import { relations } from "drizzle-orm";
import {
  boolean,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable(
  "users",
  {
    id: int("id").autoincrement().primaryKey(),
    openId: varchar("openId", { length: 64 }),
    name: varchar("name", { length: 180 }).notNull(),
    email: varchar("email", { length: 320 }).notNull(),
    passwordHash: varchar("passwordHash", { length: 255 }),
    role: mysqlEnum("role", ["admin", "technician", "requester"]).default("requester").notNull(),
    departmentId: int("departmentId"),
    active: boolean("active").default(true).notNull(),
    resetTokenHash: varchar("resetTokenHash", { length: 128 }),
    resetTokenExpiresAt: timestamp("resetTokenExpiresAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
    lastSignedIn: timestamp("lastSignedIn"),
  },
  table => ({ emailUnique: uniqueIndex("users_email_unique").on(table.email), openIdIndex: index("users_open_id_idx").on(table.openId) })
);

export const departments = mysqlTable("departments", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const categories = mysqlTable("categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 80 }).notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const tickets = mysqlTable(
  "tickets",
  {
    id: int("id").autoincrement().primaryKey(),
    protocol: varchar("protocol", { length: 32 }).notNull(),
    requesterId: int("requesterId").notNull(),
    departmentId: int("departmentId"),
    categoryId: int("categoryId"),
    assigneeId: int("assigneeId"),
    title: varchar("title", { length: 240 }).notNull(),
    description: text("description").notNull(),
    priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).default("medium").notNull(),
    status: mysqlEnum("status", ["open", "analyzing", "in_progress", "waiting_requester", "waiting_third_party", "resolved", "closed"]).default("open").notNull(),
    firstResponseAt: timestamp("firstResponseAt"),
    resolvedAt: timestamp("resolvedAt"),
    slaDueAt: timestamp("slaDueAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({ protocolUnique: uniqueIndex("tickets_protocol_unique").on(table.protocol), statusIdx: index("tickets_status_idx").on(table.status), requesterIdx: index("tickets_requester_idx").on(table.requesterId), assigneeIdx: index("tickets_assignee_idx").on(table.assigneeId), createdIdx: index("tickets_created_idx").on(table.createdAt) })
);

export const comments = mysqlTable("comments", {
  id: int("id").autoincrement().primaryKey(),
  ticketId: int("ticketId").notNull(),
  authorId: int("authorId").notNull(),
  body: text("body").notNull(),
  internal: boolean("internal").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({ ticketIdx: index("comments_ticket_idx").on(table.ticketId) }));

export const ticketHistory = mysqlTable("ticket_history", {
  id: int("id").autoincrement().primaryKey(),
  ticketId: int("ticketId").notNull(),
  actorId: int("actorId"),
  action: varchar("action", { length: 80 }).notNull(),
  description: text("description").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({ ticketIdx: index("ticket_history_ticket_idx").on(table.ticketId) }));

export const attachments = mysqlTable("attachments", {
  id: int("id").autoincrement().primaryKey(),
  ticketId: int("ticketId").notNull(),
  uploadedById: int("uploadedById").notNull(),
  originalName: varchar("originalName", { length: 255 }).notNull(),
  storageKey: varchar("storageKey", { length: 500 }).notNull(),
  mimeType: varchar("mimeType", { length: 120 }).notNull(),
  sizeBytes: int("sizeBytes").notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({ ticketIdx: index("attachments_ticket_idx").on(table.ticketId) }));

export const slaConfigs = mysqlTable("sla_configs", {
  id: int("id").autoincrement().primaryKey(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).notNull(),
  responseMinutes: int("responseMinutes").notNull(),
  resolutionMinutes: int("resolutionMinutes").notNull(),
  businessStart: varchar("businessStart", { length: 5 }).default("08:00").notNull(),
  businessEnd: varchar("businessEnd", { length: 5 }).default("18:00").notNull(),
  workingDays: varchar("workingDays", { length: 20 }).default("1,2,3,4,5").notNull(),
  active: boolean("active").default(true).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({ priorityUnique: uniqueIndex("sla_priority_unique").on(table.priority) }));

export const appSessions = mysqlTable("app_sessions", {
  id: varchar("id", { length: 96 }).primaryKey(),
  userId: int("userId").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({ userIdx: index("sessions_user_idx").on(table.userId), expiresIdx: index("sessions_expires_idx").on(table.expiresAt) }));

export const usersRelations = relations(users, ({ one, many }) => ({ department: one(departments, { fields: [users.departmentId], references: [departments.id] }), sessions: many(appSessions) }));
export const ticketsRelations = relations(tickets, ({ one, many }) => ({ requester: one(users, { fields: [tickets.requesterId], references: [users.id] }), assignee: one(users, { fields: [tickets.assigneeId], references: [users.id] }), department: one(departments, { fields: [tickets.departmentId], references: [departments.id] }), category: one(categories, { fields: [tickets.categoryId], references: [categories.id] }), comments: many(comments), history: many(ticketHistory), attachments: many(attachments) }));
export const commentsRelations = relations(comments, ({ one }) => ({ ticket: one(tickets, { fields: [comments.ticketId], references: [tickets.id] }), author: one(users, { fields: [comments.authorId], references: [users.id] }) }));
export const historyRelations = relations(ticketHistory, ({ one }) => ({ ticket: one(tickets, { fields: [ticketHistory.ticketId], references: [tickets.id] }), actor: one(users, { fields: [ticketHistory.actorId], references: [users.id] }) }));
export const sessionsRelations = relations(appSessions, ({ one }) => ({ user: one(users, { fields: [appSessions.userId], references: [users.id] }) }));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Ticket = typeof tickets.$inferSelect;
export type InsertTicket = typeof tickets.$inferInsert;
