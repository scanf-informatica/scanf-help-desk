CREATE TABLE `app_sessions` (
	`id` varchar(96) NOT NULL,
	`userId` int NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `app_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `attachments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ticketId` int NOT NULL,
	`uploadedById` int NOT NULL,
	`originalName` varchar(255) NOT NULL,
	`storageKey` varchar(500) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`sizeBytes` int NOT NULL,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `attachments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(80) NOT NULL,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `categories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `comments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ticketId` int NOT NULL,
	`authorId` int NOT NULL,
	`body` text NOT NULL,
	`internal` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `comments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `departments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(120) NOT NULL,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `departments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sla_configs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`priority` enum('low','medium','high','critical') NOT NULL,
	`responseMinutes` int NOT NULL,
	`resolutionMinutes` int NOT NULL,
	`businessStart` varchar(5) NOT NULL DEFAULT '08:00',
	`businessEnd` varchar(5) NOT NULL DEFAULT '18:00',
	`workingDays` varchar(20) NOT NULL DEFAULT '1,2,3,4,5',
	`active` boolean NOT NULL DEFAULT true,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `sla_configs_id` PRIMARY KEY(`id`),
	CONSTRAINT `sla_priority_unique` UNIQUE(`priority`)
);
--> statement-breakpoint
CREATE TABLE `ticket_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ticketId` int NOT NULL,
	`actorId` int,
	`action` varchar(80) NOT NULL,
	`description` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ticket_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tickets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`protocol` varchar(32) NOT NULL,
	`requesterId` int NOT NULL,
	`departmentId` int,
	`categoryId` int,
	`assigneeId` int,
	`title` varchar(240) NOT NULL,
	`description` text NOT NULL,
	`priority` enum('low','medium','high','critical') NOT NULL DEFAULT 'medium',
	`status` enum('open','analyzing','in_progress','waiting_requester','waiting_third_party','resolved','closed') NOT NULL DEFAULT 'open',
	`firstResponseAt` timestamp,
	`resolvedAt` timestamp,
	`slaDueAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tickets_id` PRIMARY KEY(`id`),
	CONSTRAINT `tickets_protocol_unique` UNIQUE(`protocol`)
);
--> statement-breakpoint
ALTER TABLE `users` DROP INDEX `users_openId_unique`;--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `openId` varchar(64);--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `name` varchar(180) NOT NULL;--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `email` varchar(320) NOT NULL;--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('admin','technician','requester') NOT NULL DEFAULT 'requester';--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `lastSignedIn` timestamp;--> statement-breakpoint
ALTER TABLE `users` ADD `passwordHash` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `departmentId` int;--> statement-breakpoint
ALTER TABLE `users` ADD `active` boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `resetTokenHash` varchar(128);--> statement-breakpoint
ALTER TABLE `users` ADD `resetTokenExpiresAt` timestamp;--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_email_unique` UNIQUE(`email`);--> statement-breakpoint
CREATE INDEX `sessions_user_idx` ON `app_sessions` (`userId`);--> statement-breakpoint
CREATE INDEX `sessions_expires_idx` ON `app_sessions` (`expiresAt`);--> statement-breakpoint
CREATE INDEX `attachments_ticket_idx` ON `attachments` (`ticketId`);--> statement-breakpoint
CREATE INDEX `comments_ticket_idx` ON `comments` (`ticketId`);--> statement-breakpoint
CREATE INDEX `ticket_history_ticket_idx` ON `ticket_history` (`ticketId`);--> statement-breakpoint
CREATE INDEX `tickets_status_idx` ON `tickets` (`status`);--> statement-breakpoint
CREATE INDEX `tickets_requester_idx` ON `tickets` (`requesterId`);--> statement-breakpoint
CREATE INDEX `tickets_assignee_idx` ON `tickets` (`assigneeId`);--> statement-breakpoint
CREATE INDEX `tickets_created_idx` ON `tickets` (`createdAt`);--> statement-breakpoint
CREATE INDEX `users_open_id_idx` ON `users` (`openId`);--> statement-breakpoint
ALTER TABLE `users` DROP COLUMN `loginMethod`;