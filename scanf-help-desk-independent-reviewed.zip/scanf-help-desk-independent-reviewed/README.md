# SCANF Help Desk

Sistema independente de gerenciamento de chamados da SCANF Informática. A aplicação usa React, TypeScript, Vite, Express, Drizzle ORM e MySQL. A identidade visual existente foi preservada; esta revisão concentra-se em segurança, persistência e conexão dos recursos do frontend aos endpoints do servidor.

## Arquitetura operacional

O MySQL é a fonte única de usuários, sessões, chamados, comentários, histórico, configurações e metadados de anexos. O navegador mantém apenas preferências visuais locais, como tema e largura da navegação; não usa `localStorage` para armazenar chamados ou qualquer dado operacional.

As mutações são protegidas por validação de `Origin`/`Referer` same-origin, cookie de sessão `HttpOnly; SameSite=Lax` e `Secure` quando o acesso público está em HTTPS. O primeiro cadastro é serializado por `GET_LOCK` dentro de uma transação Drizzle: aquisição, verificação da contagem, criação e liberação ocorrem na mesma conexão física do pool MySQL.

## Executar localmente

```bash
pnpm install
cp .env.example .env
pnpm db:migrate
pnpm dev
```

Abra `http://localhost:3000`. Os comandos de validação são:

```bash
pnpm check
pnpm test
pnpm build
```

## Autenticação e recuperação de senha

O primeiro usuário recebe o perfil administrador; cadastros públicos posteriores recebem o perfil solicitante. Administradores criam técnicos e outros administradores pelos endpoints protegidos. Senhas são armazenadas com `scrypt` e sessões são persistidas em `app_sessions`.

O fluxo de recuperação usa token aleatório armazenado somente como hash, expiração de uma hora, invalidação após uso e revogação das sessões existentes. A resposta HTTP nunca contém o token, inclusive em desenvolvimento. Para enviar o link, configure SMTP e `PUBLIC_APP_URL`; sem SMTP o endpoint continua genérico e não revela se o endereço existe, mas o envio não será realizado.

## Rate limit e anexos

O rate limit de login usa Redis compartilhado quando `REDIS_URL` está definido, com fallback em memória apenas para ambientes sem Redis. Em produção, Redis deve ser configurado para que bloqueios sobrevivam a reinícios e sejam compartilhados entre réplicas.

Uploads diretos presignados foram desativados porque não permitem validar o conteúdo antes de gravar o objeto. O endpoint validado recebe o conteúdo, limita o tamanho a 10 MiB, verifica a codificação Base64, inspeciona assinaturas binárias com `file-type`/PDF, compara o tipo declarado ao tipo detectado e só então grava no storage S3-compatible. O download exige autenticação e autorização no chamado.

## Variáveis de ambiente

Obrigatórias:

- `DATABASE_URL`: URL MySQL usada pelo Drizzle e pelas sessões.
- `PORT`: fornecida pelo Railway; localmente pode ser `3000`.

Recomendadas em produção:

- `REDIS_URL`: Redis compartilhado para rate limit.
- `PUBLIC_APP_URL`: URL pública usada nos links de redefinição.
- `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`, `SMTP_SECURE`: envio de recuperação de senha.
- `S3_ENDPOINT`, `S3_REGION`, `S3_BUCKET`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY`, `S3_FORCE_PATH_STYLE`: armazenamento de anexos.
- `COOKIE_SECURE=false` somente para um cenário local HTTP; em produção HTTPS não desative essa proteção.

## Railway e migrações

O `Dockerfile` instala dependências com lockfile, compila o frontend e o bundle do servidor. O comando `start:railway` executa `pnpm db:migrate` antes de iniciar o servidor. O servidor escuta `0.0.0.0` e usa a variável `PORT` injetada pelo Railway; o healthcheck é `GET /api/health`.

Configure `DATABASE_URL` antes do deploy. Configure também Redis, SMTP e S3 quando for publicar rate limit distribuído, recuperação de senha e anexos, respectivamente. Sem esses serviços opcionais, os endpoints respondem de forma explícita com dependência não configurada, sem expor segredos.

## Recursos conectados

Dashboard, fila de chamados, criação/edição, comentários, histórico, relatórios CSV/PDF, técnicos e configurações administrativas usam endpoints Express reais. O CSV é gerado no servidor e respeita o escopo de autorização do usuário. O upload validado de anexos e o download assinado são endpoints protegidos; a interface atual não apresenta upload presignado inseguro.
