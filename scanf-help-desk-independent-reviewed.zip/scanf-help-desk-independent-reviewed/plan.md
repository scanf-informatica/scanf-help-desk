# Plano — SCANF Help Desk Full Stack

## Abordagem

Aplicação React/TypeScript com Express, Drizzle ORM e MySQL como fonte única de verdade. A autenticação é própria por e-mail e senha, com hash scrypt, sessões persistidas em `app_sessions`, roles server-side e rate limit de login. O cadastro público só cria o primeiro administrador; todos os cadastros públicos seguintes são solicitantes. Administradores autenticados criam técnicos e outros administradores.

Chamados, comentários, histórico, usuários e anexos são lidos e gravados pela API. O frontend não usa `localStorage`, seeds fictícios ou identidades simuladas para a operação. Anexos usam S3-compatible storage por variáveis `S3_*`, sem dependência de fornecedor específico.

## Design

A identidade permanece Centro de Operações dark graphite com superfícies elevadas: navy profundo, cyan SCANF, cartões densos, rail lateral persistente, chips de prioridade/status e sinais de SLA em âmbar/vermelho. Inter e Space Grotesk preservam a linguagem visual original.

## Estrutura

- `client/src/pages/Home.tsx`: shell visual, dashboard, fila, drawer, relatórios e configurações conectados à API.
- `client/src/pages/Login.tsx`: login, primeiro cadastro e recuperação de senha.
- `server/fullstackRoutes.ts`: API de autenticação, chamados, comentários, histórico, SLA, configurações, relatórios e anexos.
- `server/auth.ts` e `server/security.ts`: hash, sessões, roles, rate limit e CSRF por origem.
- `server/storage.ts`: adaptador S3-compatible com presigned URLs e download autorizado.
- `drizzle/schema.ts`: modelo relacional MySQL.
- `drizzle/0000_initial_users.sql` e `drizzle/0001_minor_miss_america.sql`: migrações para banco vazio/legado.
- `Dockerfile` e `railway.toml`: build, migração e execução no Railway.

## Entrega

O build é produzido com Vite/esbuild e executado por Node/Express em `0.0.0.0:$PORT`. O healthcheck é `/api/health`. `pnpm start:railway` executa as migrações pendentes e inicia o servidor.
