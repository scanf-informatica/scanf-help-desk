export default {
  logoUrl: "https://dummyimage.com/64x64/07111f/2dd4ff.png&text=S",
};
